'use strict';

/**
 * ENCRYPTION
 */